define(
//begin v1.x content
({
	createLinkTitle: "Linkeigenschappen",
	insertImageTitle: "Afbeeldingseigenschappen",
	url: "URL:",
	text: "Beschrijving:",
	target: "Doel:",
	set: "Instellen",
	currentWindow: "Huidig venster",
	parentWindow: "Hoofdvenster",
	topWindow: "Bovenste venster",
	newWindow: "Nieuw venster"
})

//end v1.x content
);
