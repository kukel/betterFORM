define(
//begin v1.x content
({
	createLinkTitle: "Linkin ominaisuudet",
	insertImageTitle: "Kuvan ominaisuudet",
	url: "URL-osoite:",
	text: "Kuvaus:",
	target: "Kohde:",
	set: "Aseta",
	currentWindow: "Nykyinen ikkuna",
	parentWindow: "Pääikkuna",
	topWindow: "Päällimmäinen ikkuna",
	newWindow: "Uusi ikkuna"
})

//end v1.x content
);
