define(
//begin v1.x content
({
	createLinkTitle: "Właściwości odsyłacza",
	insertImageTitle: "Właściwości obrazu",
	url: "Adres URL:",
	text: "Opis:",
	target: "Cel:",
	set: "Ustaw",
	currentWindow: "Bieżące okno",
	parentWindow: "Okno macierzyste",
	topWindow: "Okno najwyższego poziomu",
	newWindow: "Nowe okno"
})

//end v1.x content
);
