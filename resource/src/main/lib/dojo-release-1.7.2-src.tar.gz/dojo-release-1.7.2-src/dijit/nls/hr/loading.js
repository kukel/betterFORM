define(
({
	loadingState: "Učitavanje...",
	errorState: "Žao nam je, došlo je do pogreške"
})
);
