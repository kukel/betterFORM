define(
//begin v1.x content
({
	buttonOk: "OK",
	buttonCancel: "Annulla",
	buttonSave: "Salva",
	itemClose: "Chiudi"
})
//end v1.x content
);
