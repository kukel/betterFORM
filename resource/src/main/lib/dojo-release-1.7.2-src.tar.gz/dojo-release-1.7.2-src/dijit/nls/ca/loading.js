define(
//begin v1.x content
({
	loadingState: "S'està carregant...",
	errorState: "Ens sap greu. S'ha produït un error."
})

//end v1.x content
);
