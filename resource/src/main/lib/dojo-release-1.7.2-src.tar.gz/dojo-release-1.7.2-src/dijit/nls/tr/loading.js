define(
//begin v1.x content
({
	loadingState: "Yükleniyor...",
	errorState: "Üzgünüz, bir hata oluştu"
})
//end v1.x content
);
